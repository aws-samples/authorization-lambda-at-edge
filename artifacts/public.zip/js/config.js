var UserPoolId = 'us-east-1_EXAMPLE';
var ClientId = '5h7EXAMPLE';
var AWSRegion = 'us-east-1';
var DomainPrefix = 'EXAMPLE';
var BaseURL = 'https://EXAMPLE.cloudfront.net';


